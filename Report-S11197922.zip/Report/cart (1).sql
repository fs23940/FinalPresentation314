-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2024 at 01:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Book Title` text NOT NULL,
  `Book ID` varchar(50) NOT NULL,
  `Book Author` text NOT NULL,
  `Book Price` int(50) NOT NULL,
  `Book Category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Book Title`, `Book ID`, `Book Author`, `Book Price`, `Book Category`) VALUES
('The Crown Prophecy', '1', 'Meg Acuna', 20, 'Fantasy'),
('Flame of Deception', '2', 'Matt Trevizo', 20, 'Fantasy'),
('This Girl\'s A Killer', '21', 'Emma C. Wells', 50, 'Mystery'),
('Where They Last Saw Her', '22', 'Emma C. Wells, Kat Martin', 25, 'Mystery'),
('Haunted', '23', 'Kat Martin', 45, 'Mystery'),
('The Lies We Conjure', '24', 'Sarah Henning', 75, 'Mystery'),
('The Midnight Club', '25', 'Margot Harrison', 20, 'Mystery'),
('Under Her Spell', '26', 'K.L Cerra', 40, 'Mystery'),
('The Mesmerist', '27', 'Caroline Woods', 30, 'Mystery'),
('Casket Case', '28', 'Lauren Wells', 50, 'Romance'),
('Pucking Sweet', '29', 'Emily Rath', 20, 'Romance'),
('Omza Of Oz', '3', 'Frank Baum', 30, 'Fantasy'),
('Counting Miracles', '30', 'Nikolas Sparks', 27, 'Romance'),
('The Book Swap', '31', 'Tessa Bickers', 19, 'Romance'),
('Ugly Love', '32', 'Colleen Hoover', 50, 'Romance'),
('Rewitched', '33', 'Lucy Jane Wood', 30, 'Romance'),
('Happy Place', '34', 'Emily Wood', 65, 'Romance'),
('W1ll1am', '35', 'Mason Cole', 10, 'Horror'),
('Dearest', '36', 'Jacquie Walters', 5, 'Horror'),
('So Thirsty', '37', 'Rachel Harrison', 8, 'Horror'),
('Sleep Tight', '38', 'J.H Market', 12, 'Horror'),
('The Girls Killer', '39', 'Emma C. Wells', 17, 'Horror'),
('The Panterra Chronicles', '4', 'Patricia Punch Barrett', 90, 'Fantasy'),
('Ward D', '40', 'Freida McFadden', 3, 'Horror'),
('One Dark Window', '41', 'Rachel Gillig', 13, 'Horror'),
('Exodus', '42', 'Peter F. Hamilton', 25, 'Science Fiction'),
('Counting', '43', 'Suzan Palumbo', 47, 'Science Fiction'),
('The Fallen Fruit', '44', 'Shawntelle Madison', 30, 'Science Fiction'),
('Songlight', '45', 'Moira Buffini', 15, 'Science Fiction'),
('Playground', '46', 'Richard Powers', 105, 'Science Fiction'),
('The Polymorph', '47', 'Max Nowaz', 52, 'Science Fiction'),
('The Midnight Library', '48', 'Matt Haig', 55, 'Science Fiction'),
('Tigers Tale', '49', 'Colleen Houck', 95, 'Adventure'),
('Le Morte D\'Artur', '5', 'Thomas Malory', 65, 'Fantasy'),
('The Found Boys', '50', 'S.D Smith', 61, 'Adventure'),
('Splinter & Ash', '51', 'Marieke Nijkamp', 75, 'Adventure'),
('Lola', '52', 'Karla Arenas Valenti', 90, 'Adventure'),
('The Long Way Around', '53', 'Anne Nesbet', 60, 'Adventure'),
('Unico Awakening', '54', 'Tezuka Sattin Gurihiru', 95, 'Adventure'),
('Countless', '55', 'Suzan Palumbo', 60, 'Adventure'),
('Grave Yard Shift', '56', 'M.L.Rio', 21, 'Thriller'),
('The Silent Patient', '57', 'Alex Michaelides', 60, 'Thriller'),
('The Inmate', '58', 'Freida McFadden', 42, 'Thriller'),
('The Perfect Son', '59', 'Freida McFadden', 88, 'Thriller'),
('Through The Looking Glass', '6', 'Lewis Carroll', 45, 'Fantasy'),
('Never Lie', '60', 'Freida McFadden', 35, 'Thriller'),
('You Can Do It', '61', 'Rob Schneider', 55, 'Humor'),
('A Great Big Visual Hug', '62', 'Andres J.Colemenres', 70, 'Humor'),
('Grave Talk', '63', 'Nick Spalding', 30, 'Humor'),
('Yes Please', '64', 'Amy Poehler', 60, 'Humor'),
('Lamb', '65', 'Christopher Moore', 83, 'Humor'),
('Wonka', '66', 'Roald Dahl', 63, 'Humor'),
('Bridesmaid Undercover', '67', 'Meghan Quinn', 99, 'Humor'),
('Five Children And It', '7', 'Elijah Nesbit', 65, 'Fantasy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Book ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
