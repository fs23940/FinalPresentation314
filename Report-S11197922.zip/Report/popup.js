// Show the popup
function openPopup() {
    document.getElementById("cartPopup").style.display = "flex";
  }
  
  // Close popup and continue shopping
  function continueShopping() {
    document.getElementById("cartPopup").style.display = "none";
  }
  
  // Close popup and redirect to cart page
  function viewCart() {
    document.getElementById("cartPopup").style.display = "none";
    window.location.href = "cart.html"; // Redirect to the cart page
  }
  
  


  
  
