let cartItems = [];

// Function to add item to cart
function addToCart(name, price, image) {
    // Check if the item is already in the cart
    const existingItemIndex = cartItems.findIndex(cartItem => cartItem.name === name);
    
    if (existingItemIndex > -1) {
        // Show message if item is already in the cart
        alert(`${name} is already in your cart.`);
    } else {
        // Add new item to cart
        const item = {
            name: name,
            price: price,
            image: image,
            quantity: 1
        };
        cartItems.push(item); // Add new item to cart
    }

    updateCartDisplay(); // Update display after adding an item
}

// Function to increase quantity from the cart
function increaseQuantity(name) {
    const itemIndex = cartItems.findIndex(cartItem => cartItem.name === name);
    if (itemIndex > -1) {
        cartItems[itemIndex].quantity += 1; // Increase quantity
        updateCartDisplay(); // Update display after increasing quantity
    }
}

// Function to decrease quantity or remove from cart if zero
function decreaseQuantity(name) {
    const itemIndex = cartItems.findIndex(cartItem => cartItem.name === name);
    if (itemIndex > -1) {
        if (cartItems[itemIndex].quantity > 1) {
            cartItems[itemIndex].quantity -= 1; // Decrease quantity
        } else {
            cartItems.splice(itemIndex, 1); // Remove item from cart if quantity is 0
        }
        updateCartDisplay(); // Update display after decreasing quantity or removing item
    }
}

// Function to update cart display
function updateCartDisplay() {
    const cartItemsContainer = document.querySelector('.cart-items');
    const cartTotal = document.querySelector('.cart-total-price');
    cartItemsContainer.innerHTML = ''; // Clear previous items
    let total = 0;

    cartItems.forEach(item => {
        // Create cart row container
        const cartRow = document.createElement('div');
        cartRow.classList.add('cart-row');
        
        // Add item, image, price, and quantity
        cartRow.innerHTML = `
            <span class="cart-item cart-column">${item.name}</span>
            <span class="cart-image cart-column">
                <img src="${item.image}" alt="${item.name}" style="width: 50px; height: 50px; margin-right: 10px;">
            </span>
            <span class="cart-price cart-column">${item.price}</span>
            <span class="cart-quantity cart-column">
                <button onclick="increaseQuantity('${item.name}')">+</button> 
                ${item.quantity} 
                <button onclick="decreaseQuantity('${item.name}')">-</button>
            </span>
        `;

        // Append the row to the cart items container
        cartItemsContainer.appendChild(cartRow);

        // Calculate total price
        total += parseFloat(item.price.replace('$', '')) * item.quantity;
    });

    // Update the total price in the cart display
    cartTotal.innerText = `$${total.toFixed(2)}`;
}
