<?php
$servername = "localhost";  // Your database server, often "localhost"
$username = "fee";  // Database username
$password = "Naidovi$23";  // Database password
$dbname = "cart";  // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>


