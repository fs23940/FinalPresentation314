﻿Imports System.Data.OleDb

Partial Class AllReviews
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim isbn As String = Request.QueryString("isbn")
            If Not String.IsNullOrEmpty(isbn) Then
                BindReviews(isbn)
            End If
        End If
    End Sub

    Private Sub BindReviews(ByVal isbn As String)
        Dim connString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\SuvaBookShop.mdb"
        Dim query As String = "SELECT Username, Review, [Star Ratings] FROM Reviews WHERE [ISBN Number] = ?"

        Using connection As New OleDbConnection(connString)
            Using command As New OleDbCommand(query, connection)
                command.Parameters.AddWithValue("?", isbn)
                Dim adapter As New OleDbDataAdapter(command)
                Dim reviewsTable As New DataTable()
                adapter.Fill(reviewsTable)
                RptReviews.DataSource = reviewsTable
                RptReviews.DataBind()
            End Using
        End Using
    End Sub
End Class