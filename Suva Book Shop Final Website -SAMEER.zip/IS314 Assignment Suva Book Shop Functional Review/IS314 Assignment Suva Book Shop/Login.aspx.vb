﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Text

Public Class Login1
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        Dim email As String = txtEmail.Text
        Dim password As String = txtPassword.Text


        Dim query As String = "SELECT Password, Username FROM Users WHERE Email = ?"
        ADsAccount2.SelectCommand = query
        ADsAccount2.SelectParameters.Clear()
        ADsAccount2.SelectParameters.Add("Email", email)

        Dim dv As DataView = CType(ADsAccount2.Select(DataSourceSelectArguments.Empty), DataView)

        If dv.Count = 1 Then
            Dim storedHash As String = dv(0)("Password").ToString()
            Dim username As String = dv(0)("Username").ToString()

            If VerifyPassword(password, storedHash) Then

                Session("UserEmail") = email
                Session("Username") = username
                Response.Redirect("Home.aspx")
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "LoginFailed", "alert('Incorrect password.');", True)
            End If
        Else
            ClientScript.RegisterStartupScript(Me.GetType(), "LoginFailed", "alert('Email not found.');", True)
        End If
    End Sub

    Private Function VerifyPassword(ByVal enteredPassword As String, ByVal storedHash As String) As Boolean
        Dim parts As String() = storedHash.Split(":"c)
        If parts.Length <> 2 Then Return False

        Dim salt As String = parts(0)
        Dim hash As String = parts(1)

        Dim saltedPassword As String = salt & enteredPassword
        Using sha256 As SHA256 = SHA256.Create()
            Dim saltedPasswordBytes As Byte() = Encoding.UTF8.GetBytes(saltedPassword)
            Dim enteredHashBytes As Byte() = sha256.ComputeHash(saltedPasswordBytes)
            Dim enteredHash As String = Convert.ToBase64String(enteredHashBytes)

            Return enteredHash = hash
        End Using
    End Function
End Class