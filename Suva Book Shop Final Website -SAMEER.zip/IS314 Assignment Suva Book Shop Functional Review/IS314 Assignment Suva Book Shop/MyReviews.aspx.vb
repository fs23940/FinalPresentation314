﻿Imports System.Data.OleDb

Partial Class MyReviews
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("UserEmail") Is Nothing Then
                ClientScript.RegisterStartupScript(Me.GetType(), "Alert", "alert('Please log in to view your reviews.');", True)
                rptMyReviews.Visible = False
            Else
                Dim username As String = Session("Username").ToString()
                BindReviews(username)
            End If
        End If
    End Sub

    Private Sub BindReviews(ByVal username As String)
        AdsMyReviews.DataBind()
        rptMyReviews.DataSource = AdsMyReviews
        rptMyReviews.DataBind()
    End Sub

    Protected Sub rptMyReviews_ItemCommand(ByVal source As Object, ByVal e As RepeaterCommandEventArgs)
        If e.CommandName = "Delete" Then
            Dim reviewID As Integer = Convert.ToInt32(e.CommandArgument)
            DeleteReview(reviewID)
        ElseIf e.CommandName = "Edit" Then
            Dim reviewID As Integer = Convert.ToInt32(e.CommandArgument)
            Response.Redirect("EditReview.aspx?reviewID=" & reviewID) ' Corrected this line to concatenate reviewID
        End If
    End Sub

    Private Sub DeleteReview(ByVal reviewID As Integer)
        Dim connString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\SuvaBookShop.mdb"
        Dim query As String = "DELETE FROM Reviews WHERE ReviewID = ?"

        Using connection As New OleDbConnection(connString)
            Dim command As New OleDbCommand(query, connection)
            command.Parameters.AddWithValue("?", reviewID)

            Try
                connection.Open()
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                If rowsAffected > 0 Then
                    ClientScript.RegisterStartupScript(Me.GetType(), "Alert", "alert('Review deleted successfully.');", True)
                Else
                    ClientScript.RegisterStartupScript(Me.GetType(), "Alert", "alert('Review not found.');", True)
                End If
            Catch ex As Exception
                ClientScript.RegisterStartupScript(Me.GetType(), "Alert", "alert('Error deleting review: " & ex.Message.Replace("'", "\'") & "');", True)
            End Try
        End Using

        Dim username As String = Session("Username").ToString()
        BindReviews(username)
    End Sub
End Class