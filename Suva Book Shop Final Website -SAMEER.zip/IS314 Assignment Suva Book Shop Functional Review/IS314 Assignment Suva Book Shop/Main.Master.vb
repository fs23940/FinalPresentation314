﻿Imports System

Partial Class Main
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Session("UserEmail") IsNot Nothing Then

                btnLogout.Style("display") = "block"
                btnLogin.Style("display") = "none"
                btnRegister.Style("display") = "none"
            Else

                btnLogout.Style("display") = "none"
                btnLogin.Style("display") = "block"
                btnRegister.Style("display") = "block"
            End If
        End If
    End Sub

    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs)

        Session.Clear()
        Response.Redirect("Home.aspx")
    End Sub
End Class