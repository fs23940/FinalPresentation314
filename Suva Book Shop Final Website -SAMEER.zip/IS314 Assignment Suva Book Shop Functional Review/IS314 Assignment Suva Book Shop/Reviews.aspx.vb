﻿Imports System.Data.OleDb

Partial Class Reviews
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("UserEmail") Is Nothing Then
                Response.Redirect("Login.aspx")
            End If

            Dim bookTitle As String = Request.QueryString("bookTitle")
            Dim isbn As String = Request.QueryString("isbn")

            lblSelectedBookTitle.Text = bookTitle
            lblSelectedISBN.Text = isbn
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        If Not String.IsNullOrEmpty(lblSelectedBookTitle.Text) AndAlso Not String.IsNullOrEmpty(txtReview.Text) AndAlso ddlRating.SelectedItem IsNot Nothing Then
            Dim selectedBookTitle As String = lblSelectedBookTitle.Text
            Dim selectedISBN As String = lblSelectedISBN.Text
            Dim reviewText As String = txtReview.Text
            Dim rating As String = ddlRating.SelectedValue

            Dim username As String = GetUsernameByEmail(Session("UserEmail").ToString())
            Dim userEmail As String = Session("UserEmail").ToString() 
            If username IsNot Nothing Then
                AdsReview.InsertParameters("Book_Title").DefaultValue = selectedBookTitle
                AdsReview.InsertParameters("ISBN_Number").DefaultValue = selectedISBN
                AdsReview.InsertParameters("Review").DefaultValue = reviewText
                AdsReview.InsertParameters("Star_Ratings").DefaultValue = rating
                AdsReview.InsertParameters("Username").DefaultValue = username
                AdsReview.InsertParameters("UserEmail").DefaultValue = userEmail

                Try
                    AdsReview.Insert()
                    ClientScript.RegisterStartupScript(Me.GetType(), "Success", "alert('Thank you for your review!'); window.location.href='Home.aspx';", True)
                Catch ex As Exception
                    ClientScript.RegisterStartupScript(Me.GetType(), "Error", "alert('There was an error submitting your review. Please try again.');", True)
                End Try
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "UserError", "alert('User not found.');", True)
            End If
        Else
            ClientScript.RegisterStartupScript(Me.GetType(), "FieldError", "alert('Please fill in all fields.');", True)
        End If
    End Sub

    Private Function GetUsernameByEmail(ByVal email As String) As String
        Dim username As String = Nothing
        Dim connString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\SuvaBookShop.mdb"
        Using connection As New OleDbConnection(connString)
            Dim command As New OleDbCommand("SELECT Username FROM Users WHERE Email = ?", connection)
            command.Parameters.AddWithValue("?", email)

            Try
                connection.Open()
                Dim result = command.ExecuteScalar()
                If result IsNot Nothing Then
                    username = result.ToString()
                End If
            Catch ex As Exception

            End Try
        End Using
        Return username
    End Function
End Class