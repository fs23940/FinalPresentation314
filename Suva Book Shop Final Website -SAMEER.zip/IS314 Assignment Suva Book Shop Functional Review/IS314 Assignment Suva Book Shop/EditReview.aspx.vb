﻿Imports System
Imports System.Web.UI

Partial Public Class EditReview
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadReviewData()
        End If
    End Sub

    Private Sub LoadReviewData()
        AdsEditReview.Select(DataSourceSelectArguments.Empty)
    End Sub

    Protected Sub btnUpdateReview_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdateReview.Click
        Try
            AdsEditReview.UpdateParameters.Clear()
            AdsEditReview.UpdateParameters.Add("Review", txtReview.Text.Trim())
            AdsEditReview.UpdateParameters.Add("Star_Ratings", ddlRating.SelectedValue)
            AdsEditReview.UpdateParameters.Add("ReviewID", Request.QueryString("reviewID"))

            Dim rowsAffected As Integer = AdsEditReview.Update()

            If rowsAffected > 0 Then
                ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Review updated successfully.'); window.location.href='Books.aspx';", True)
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Failed to update the review.');", True)
            End If

        Catch ex As Exception
            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('An error occurred while updating the review: " & ex.Message.Replace("'", "\'") & "');", True)
        End Try
    End Sub

End Class