﻿Partial Class Reviews
    Inherits System.Web.UI.Page

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        If ddlCategory.SelectedItem IsNot Nothing AndAlso Not String.IsNullOrEmpty(txtReview.Text) AndAlso ddlRating.SelectedItem IsNot Nothing Then
            Dim selectedBookTitle As String = ddlCategory.SelectedItem.Text
            Dim selectedISBN As String = ddlCategory.SelectedItem.Value
            Dim reviewText As String = txtReview.Text
            Dim rating As String = ddlRating.SelectedValue

            AdsReview.InsertParameters("Book_Title").DefaultValue = selectedBookTitle
            AdsReview.InsertParameters("ISBN_Number").DefaultValue = selectedISBN
            AdsReview.InsertParameters("Review").DefaultValue = reviewText
            AdsReview.InsertParameters("Star_Ratings").DefaultValue = rating

            Try
                AdsReview.Insert()
                lblMessage.Text = "Thank you for your review!"
            Catch ex As Exception
                lblMessage.Text = "There was an error submitting your review. Please try again."
            End Try
        Else
            lblMessage.Text = "Please fill in all fields."
        End If
    End Sub
End Class