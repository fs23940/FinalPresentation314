let cart = [];

function addToCart(title, price) {
    const book = { title, price, quantity: 1 };
    const existingItem = cart.find(item => item.title === title);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push(book);
    }

    updateCartDisplay();
    alert(`${title} has been added to your cart!`);
}

function updateCartDisplay() {
    const cartItemsContainer = document.querySelector('.cart-items');
    cartItemsContainer.innerHTML = ''; // Clear previous items
    let total = 0;

    cart.forEach(book => {
        const cartRow = document.createElement('div');
        cartRow.classList.add('cart-row');
        cartRow.innerHTML = `
            <div>${book.title}</div>
            <div>$${book.price.toFixed(2)}</div>
            <div>${book.quantity}</div>
        `;
        cartItemsContainer.append(cartRow);
        total += book.price * book.quantity;
    });

    document.querySelector('.cart-total-price').innerText = `$${total.toFixed(2)}`;
}

function purchaseClicked() {
    alert('Thank you for your purchase!');
    cart = []; // Clear the cart
    updateCartDisplay();
}
