﻿Imports System.Data.OleDb
Imports System.Web.UI

Partial Class ReservedBooks
    Inherits System.Web.UI.Page

    ' Connection string for your MS Access database
    Private connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\SuvaBookShop.mdb;"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("User") Is Nothing Then
                Response.Redirect("~/Login.aspx") ' Redirect to login page if not logged in
            End If

            LoadBooks()
            LoadReservedBooks()
        End If
    End Sub

    ' Load books into the dropdown list
    Private Sub LoadBooks()
        Using connection As New OleDbConnection(connectionString)
            Dim command As New OleDbCommand("SELECT [Book Title] FROM [Books Inventory]", connection)

            Try
                connection.Open()
                Dim reader As OleDbDataReader = command.ExecuteReader()

                ddlBooks.Items.Clear() ' Clear existing items before adding new ones
                While reader.Read()
                    ' Add book title to the dropdown
                    ddlBooks.Items.Add(New ListItem(reader("Book Title").ToString(), reader("Book Title").ToString()))
                End While
            Catch ex As OleDbException
                lblError.Text = "Error loading books: " & ex.Message
                lblError.Visible = True
            End Try
        End Using
    End Sub

    ' Load available stock for the selected book
    Protected Sub ddlBooks_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim bookTitle As String = ddlBooks.SelectedValue
        DisplayAvailableStock(bookTitle)
    End Sub

    ' Display available stock
    Private Sub DisplayAvailableStock(ByVal bookTitle As String)
        Using connection As New OleDbConnection(connectionString)
            Dim command As New OleDbCommand("SELECT [Quantity Available] FROM [Books Inventory] WHERE [Book Title] = ?", connection)
            command.Parameters.AddWithValue("?", bookTitle)

            Try
                connection.Open()
                Dim availableQuantity As Object = command.ExecuteScalar()

                If availableQuantity IsNot Nothing Then
                    lblAvailableStock.Text = "Available Stock: " & availableQuantity.ToString()
                Else
                    lblAvailableStock.Text = "Book not found."
                End If
            Catch ex As OleDbException
                lblError.Text = "Error loading stock: " & ex.Message
                lblError.Visible = True
            End Try
        End Using
    End Sub

    Protected Sub btnReserve_Click(ByVal sender As Object, ByVal e As EventArgs)
        If String.IsNullOrEmpty(ddlBooks.SelectedValue) OrElse String.IsNullOrEmpty(txtQuantity.Text) OrElse String.IsNullOrEmpty(txtCustomerName.Text) OrElse String.IsNullOrEmpty(txtCustomerEmail.Text) Then
            lblError.Text = "Please fill all fields correctly."
            lblError.Visible = True
            Return
        End If

        Dim bookTitle As String = ddlBooks.SelectedItem.Text ' Get selected book title
        Dim quantity As Integer
        Dim customerName As String = txtCustomerName.Text.Trim()
        Dim customerEmail As String = txtCustomerEmail.Text.Trim()
        Dim reservationDate As DateTime = DateTime.Now
        Dim expirationDate As DateTime = reservationDate.AddHours(12) ' 12-hour expiration

        If Not Integer.TryParse(txtQuantity.Text.Trim(), quantity) OrElse quantity <= 0 Then
            lblError.Text = "Please fill all fields correctly."
            lblError.Visible = True
            Return
        End If

        Using connection As New OleDbConnection(connectionString)
            Dim command As New OleDbCommand("INSERT INTO [Reservations] (BookTitle, Quantity, CustomerName, CustomerEmail, ReservationDate, ExpirationDate) VALUES (?, ?, ?, ?, ?, ?)", connection)

            ' Adding parameters with explicit data types
            command.Parameters.Add("?", OleDbType.VarChar).Value = bookTitle
            command.Parameters.Add("?", OleDbType.Integer).Value = quantity
            command.Parameters.Add("?", OleDbType.VarChar).Value = customerName
            command.Parameters.Add("?", OleDbType.VarChar).Value = customerEmail
            command.Parameters.Add("?", OleDbType.Date).Value = reservationDate
            command.Parameters.Add("?", OleDbType.Date).Value = expirationDate

            Try
                connection.Open()
                command.ExecuteNonQuery()
                lblSuccess.Text = "Reservation successful." ' Set success message
                lblSuccess.Visible = True

                ' Clear the form fields after a successful reservation
                ClearForm()
                LoadReservedBooks() ' Refresh the GridView to show updated reservations
            Catch ex As OleDbException
                lblError.Text = "Error making reservation: " & ex.Message
                lblError.Visible = True
            Finally
                connection.Close()
            End Try
        End Using
    End Sub

    ' Method to clear form fields
    Private Sub ClearForm()
        ddlBooks.SelectedIndex = -1 ' Reset the dropdown selection
        txtQuantity.Text = String.Empty ' Clear the quantity text box
        txtCustomerName.Text = String.Empty ' Clear the customer name text box
        txtCustomerEmail.Text = String.Empty ' Clear the customer email text box
        lblAvailableStock.Text = String.Empty ' Clear available stock label
        lblError.Visible = False ' Hide error messages
        lblSuccess.Visible = True ' Keep success message visible if it was shown
    End Sub

    Private Sub LoadReservedBooks()
        ' Get the user's email from the session
        Dim userEmail As String = If(Session("User") IsNot Nothing, Session("User").ToString(), String.Empty)

        If String.IsNullOrEmpty(userEmail) Then
            lblError.Text = "User session not found. Please log in again."
            lblError.Visible = True
            Return
        End If

        Using connection As New OleDbConnection(connectionString)
            ' SQL query to select all reservations made by the logged-in user
            Dim command As New OleDbCommand("SELECT * FROM [Reservations] WHERE CustomerEmail = ?", connection)
            command.Parameters.AddWithValue("?", userEmail)

            Dim adapter As New OleDbDataAdapter(command)
            Dim table As New DataTable()

            Try
                connection.Open()
                adapter.Fill(table)

                ' Bind data to GridView if reservations exist
                If table.Rows.Count > 0 Then
                    GridViewReservations.DataSource = table
                    GridViewReservations.DataBind()
                    lblYourReservedBooks.Text = "" ' Clear any "no reservations" message
                    lblYourReservedBooks.ForeColor = System.Drawing.Color.Black
                Else
                    ' Show message if no reservations are found
                    GridViewReservations.DataSource = Nothing
                    GridViewReservations.DataBind()
                    lblYourReservedBooks.Text = "No reservations found."
                    lblYourReservedBooks.ForeColor = System.Drawing.Color.Red
                End If
            Catch ex As OleDbException
                lblError.Text = "Error loading reservations: " & ex.Message
                lblError.Visible = True
            End Try
        End Using
    End Sub


    ' Cancel a reservation
    Private Sub CancelReservation(ByVal reservationID As Integer)
        Using connection As New OleDbConnection(connectionString)
            ' First, retrieve the reservation details to restore stock
            Dim command As New OleDbCommand("SELECT [BookTitle], [Quantity] FROM [Reservations] WHERE [ReservationID] = ?", connection)
            command.Parameters.AddWithValue("?", reservationID)

            Try
                connection.Open()
                Dim reader As OleDbDataReader = command.ExecuteReader()

                If reader.Read() Then
                    Dim bookTitle As String = reader("BookTitle").ToString()
                    Dim quantity As Integer = Convert.ToInt32(reader("Quantity"))

                    ' Delete the reservation
                    Dim deleteCommand As New OleDbCommand("DELETE FROM [Reservations] WHERE [ReservationID] = ?", connection)
                    deleteCommand.Parameters.AddWithValue("?", reservationID)
                    deleteCommand.ExecuteNonQuery()

                    ' Restore the stock
                    Dim restoreCommand As New OleDbCommand("UPDATE [Books Inventory] SET [Quantity Available] = [Quantity Available] + ? WHERE [Book Title] = ?", connection)
                    restoreCommand.Parameters.AddWithValue("?", quantity)
                    restoreCommand.Parameters.AddWithValue("?", bookTitle)
                    restoreCommand.ExecuteNonQuery()
                End If
            Catch ex As OleDbException
                lblError.Text = "Error cancelling reservation: " & ex.Message
                lblError.Visible = True
            End Try
        End Using
    End Sub

    ' Handle GridView commands (e.g., cancel reservation)
    Protected Sub GridViewReservations_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "CancelReservation" Then
            Dim reservationID As Integer = Convert.ToInt32(e.CommandArgument)
            CancelReservation(reservationID)
            LoadReservedBooks() ' Refresh the GridView to show updated reservations
        End If
    End Sub
End Class
