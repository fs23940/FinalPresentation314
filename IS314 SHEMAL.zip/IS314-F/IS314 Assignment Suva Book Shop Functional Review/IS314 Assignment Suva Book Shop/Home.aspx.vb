﻿Imports System.Data.OleDb
Imports System.Timers

Partial Class Register1
    Inherits System.Web.UI.Page

    Protected WithEvents lblConfirmation As Global.System.Web.UI.WebControls.Label

    ' Connection string for your MS Access database
    Private connString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\SuvaBookShop.mdb;"
 

    ' Save the reservation to the database
    Private Function SaveReservationToDatabase(ByVal bookTitle As String, ByVal reservationDate As DateTime, ByVal expirationDate As DateTime) As Integer
        Dim reservationID As Integer = 0

        Using connection As New OleDbConnection(connString)
            Dim command As New OleDbCommand("INSERT INTO Reservations (BookTitle, ReservationDate, ExpirationDate, Status) VALUES (@BookTitle, @ReservationDate, @ExpirationDate, @Status)", connection)

            ' Add parameters with explicit types
            command.Parameters.AddWithValue("@BookTitle", bookTitle)
            command.Parameters.Add("@ReservationDate", OleDbType.Date).Value = reservationDate
            command.Parameters.Add("@ExpirationDate", OleDbType.Date).Value = expirationDate
            command.Parameters.AddWithValue("@Status", "Active")

            connection.Open()
            command.ExecuteNonQuery() ' Execute the insert command

            ' Now get the last inserted ID
            command.CommandText = "SELECT MAX(ReservationID) FROM Reservations"
            reservationID = Convert.ToInt32(command.ExecuteScalar())
        End Using

        Return reservationID
    End Function


    ' Starts the timer to automatically cancel the reservation after 12 hours
    Private Sub StartReservationTimer(ByVal reservationID As Integer, ByVal expirationTime As DateTime)
        Dim timer As New Timers.Timer(43200000) ' 12 hours in milliseconds
        AddHandler timer.Elapsed, Sub(sender, e) CheckAndCancelReservation(reservationID, expirationTime)
        timer.AutoReset = False
        timer.Start()
    End Sub

    ' Checks the reservation's expiration time and cancels it if expired
    Private Sub CheckAndCancelReservation(ByVal reservationID As Integer, ByVal expirationTime As DateTime)
        If DateTime.Now >= expirationTime Then
            CancelReservation(reservationID)
        End If
    End Sub

    ' Cancel reservation by updating the status in the database
    Private Sub CancelReservation(ByVal reservationID As Integer)
        Using connection As New OleDbConnection(connString)
            Dim command As New OleDbCommand("UPDATE Reservations SET Status = 'Canceled' WHERE ReservationID = @ReservationID", connection)
            command.Parameters.AddWithValue("@ReservationID", reservationID)

            connection.Open()
            command.ExecuteNonQuery()
        End Using
    End Sub

    Protected Sub btnViewReservedBooks_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnViewReservedBooks.Click
        Response.Redirect("~/ReservedBooks.aspx")

    End Sub
End Class
