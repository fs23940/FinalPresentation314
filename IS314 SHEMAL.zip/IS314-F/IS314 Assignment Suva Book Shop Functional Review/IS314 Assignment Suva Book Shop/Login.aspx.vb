﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Data

Public Class Login1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Check if the user is already logged in
        If Session("User") IsNot Nothing Then
            Response.Redirect("Home.aspx") ' Redirect to home page if already logged in
        End If
    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        Dim email As String = txtEmail.Text
        Dim password As String = txtPassword.Text

        AdsAccount.SelectCommand = "SELECT [Account ID], [Password] FROM Accounts WHERE [Email] = ?"
        AdsAccount.SelectParameters.Clear()
        AdsAccount.SelectParameters.Add("Email", email)
        Dim data As DataView = CType(AdsAccount.Select(DataSourceSelectArguments.Empty), DataView)

        If data.Count > 0 Then
            Dim accountId As Integer = Convert.ToInt32(data(0)("Account ID"))
            Dim storedValue As String = data(0)("Password").ToString()
            Dim parts As String() = storedValue.Split(":"c)

            If parts.Length = 2 Then
                Dim storedSalt As String = parts(0)
                Dim storedHash As String = parts(1)

                Dim saltedPassword As String = storedSalt & password
                Using sha256 As SHA256 = SHA256.Create()
                    Dim saltedPasswordBytes As Byte() = Encoding.UTF8.GetBytes(saltedPassword)
                    Dim hashBytes As Byte() = sha256.ComputeHash(saltedPasswordBytes)
                    Dim enteredHash As String = Convert.ToBase64String(hashBytes)

                    If enteredHash = storedHash Then
                        ' Set session variable to indicate the user is logged in
                        Session("User") = accountId.ToString() ' Store the account ID or email

                        AdsLogin.InsertParameters("AccountID").DefaultValue = accountId.ToString()
                        AdsLogin.InsertParameters("column1").DefaultValue = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                        AdsLogin.Insert()

                        Response.Redirect("Home.aspx") ' Redirect to the home page
                    Else
                        Response.Write("<script>alert('Invalid email or password. Please try again.');</script>")
                    End If
                End Using
            Else
                Response.Write("<script>alert('Invalid password format in the database.');</script>")
            End If
        Else
            Response.Write("<script>alert('Invalid email or password. Please try again.');</script>")
        End If
    End Sub

    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs)
        Session.Abandon() ' Clear the session
        Response.Redirect("Login.aspx") ' Redirect to the login page
    End Sub
End Class
