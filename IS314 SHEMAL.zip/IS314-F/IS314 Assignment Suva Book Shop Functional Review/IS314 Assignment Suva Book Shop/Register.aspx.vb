﻿Imports System.Security.Cryptography
Imports System.Text
Public Class Register2
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnRegister_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRegister.Click
        Try

            Dim hashedPassword As String = HashPassword(txtPassword.Text)


            AdsCreateaccounts.InsertParameters("Email").DefaultValue = txtEmail.Text
            AdsCreateaccounts.InsertParameters("Name").DefaultValue = txtName.Text
            AdsCreateaccounts.InsertParameters("Password").DefaultValue = hashedPassword
            AdsCreateaccounts.InsertParameters("Gender").DefaultValue = ddlGender.SelectedValue
            AdsCreateaccounts.InsertParameters("Age").DefaultValue = txtAge.Text


            Dim rowsAffected As Integer = AdsCreateaccounts.Insert()


            If rowsAffected > 0 Then
                ClientScript.RegisterStartupScript(Me.GetType(), "Success", "alert('Account Created Successfully');", True)
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "Failure", "alert('Account creation failed');", True)
            End If

        Catch ex As Exception

            ClientScript.RegisterStartupScript(Me.GetType(), "Error", "alert('Error: " & ex.Message.Replace("'", "\'") & "');", True)
        End Try


        Response.Redirect("Home.aspx")
    End Sub
    Private Function HashPassword(ByVal password As String) As String

        Dim saltBytes As Byte() = New Byte(15) {}
        Using rng As New RNGCryptoServiceProvider()
            rng.GetBytes(saltBytes)
        End Using
        Dim salt As String = Convert.ToBase64String(saltBytes)


        Dim saltedPassword As String = salt & password


        Using sha256 As SHA256 = sha256.Create()
            Dim saltedPasswordBytes As Byte() = Encoding.UTF8.GetBytes(saltedPassword)
            Dim hashBytes As Byte() = sha256.ComputeHash(saltedPasswordBytes)
            Dim hash As String = Convert.ToBase64String(hashBytes)


            Return salt & ":" & hash
        End Using
    End Function
End Class